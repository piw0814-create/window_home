package test;


import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.security.Keys;
import org.springframework.stereotype.Component;
import java.util.Date;
import java.security.Key;

@Component
public class TokenProvider {
    private final String SECRET = "day2-secret-key-must-be-at-least-32-chars!!"; 
    private final Key key = Keys.hmacShaKeyFor(SECRET.getBytes());
    
    public String generate(String userId) {
        return Jwts.builder()
                .setSubject(userId)
                .setExpiration(new Date(System.currentTimeMillis() + 1800000)) // 30분
                .signWith(key)
                .compact();
    }
}
