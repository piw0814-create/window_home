package test;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;


@RestController
@RequestMapping("/api/auth")
public class AuthController {
    
    @Autowired
    private AuthService authService;

    public record AuthRequest(String id, String password) {}
    public record TokenResponse(String token) {}

    @PostMapping("/register")
    public ResponseEntity<String> register(@RequestBody AuthRequest req) {
        authService.register(req.id(), req.password());
        return ResponseEntity.status(201).body("가입 완료");
    }

    @PostMapping("/login")
    public ResponseEntity<TokenResponse> login(@RequestBody AuthRequest req) {
        String token = authService.login(req.id(), req.password());
        return ResponseEntity.ok(new TokenResponse(token));
    }
}
