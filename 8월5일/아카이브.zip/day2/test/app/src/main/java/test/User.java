package test;

import org.mindrot.jbcrypt.BCrypt;

public class User {
    private final String id;
    private final String hashedPw;

    private User(String id, String hashedPw) {
        this.id = id;
        this.hashedPw = hashedPw;
    }

    public static User of(String id, String rawPw) {
        String hash = BCrypt.hashpw(rawPw, BCrypt.gensalt(12));
        return new User(id, hash);
    }

    public boolean matchPw(String rawPw) {
        return BCrypt.checkpw(rawPw, this.hashedPw);
    }

    public String getId() { return id; }
}