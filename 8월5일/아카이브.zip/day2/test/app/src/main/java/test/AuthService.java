package test;


import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class AuthService {
    private final TokenProvider tokenProvider;
    private final Map<String, User> store = new HashMap<>();

    @Autowired
    public AuthService(TokenProvider tokenProvider) {
        this.tokenProvider = tokenProvider;
    }

    public void register(String id, String pw) {
        if (store.containsKey(id)) throw new RuntimeException("이미 존재하는 ID");
        store.put(id, User.of(id, pw));
    }

    public String login(String id, String pw) {
        User user = store.get(id);
        if (user == null || !user.matchPw(pw)) {
            throw new RuntimeException("인증 실패");
        }
        return tokenProvider.generate(id);
    }
}
