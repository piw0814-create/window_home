package login_server;

import lombok.RequiredArgsConstructor;
import org.mindrot.jbcrypt.BCrypt;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@RequiredArgsConstructor
public class AuthService {

    private final UserRepository userRepository;
    private final TokenProvider tokenProvider;

    // 이 메서드는 JPA를 적용한 Repository를 통해 데이터 베이스와 연동되는 부분임을
    // 명시한다.
    @Transactional
    public void register(String username, String rawPassword) {
        if (userRepository.existsByUsername(username)) {
            throw new RuntimeException("이미 존재하는 아이디입니다.");
        }

        String hashedPassword = BCrypt.hashpw(rawPassword, BCrypt.gensalt(12));

        User user = User.builder()
                .username(username)
                .password(hashedPassword)
                .build();

        // Entity 에 데이터를 담아 save 메서드를 호출하면
        // 테이블에 행이 추가되어 저장된다.
        userRepository.save(user);
    }

    @Transactional(readOnly = true)
    public String login(String username, String rawPassword) {
        User user = userRepository.findByUsername(username)
                .orElseThrow(() -> new RuntimeException("사용자를 찾을 수 없거나 비밀번호가 틀렸습니다."));

        if (!BCrypt.checkpw(rawPassword, user.getPassword())) {
            throw new RuntimeException("사용자를 찾을 수 없거나 비밀번호가 틀렸습니다.");
        }

        return tokenProvider.generate(user.getUsername());
    }
}