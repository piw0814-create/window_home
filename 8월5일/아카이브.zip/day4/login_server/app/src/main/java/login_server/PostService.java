package login_server;


import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@RequiredArgsConstructor
public class PostService {
    private final PostRepository postRepository;

    public record PostRequest(String title, String content) {}
    public record PostResponse(Long id, String title, String content) {
        public static PostResponse from(Post post) {
            return new PostResponse(post.getId(), post.getTitle(), post.getContent());
        }
    }

    @Transactional
    public PostResponse create(PostRequest req) {
        Post post = Post.builder().title(req.title()).content(req.content()).build();
        return PostResponse.from(postRepository.save(post));
    }
}
