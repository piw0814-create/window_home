package login_server;

import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/auth")
@RequiredArgsConstructor
public class AuthController {
    
    private final AuthService authService;

    public record AuthRequest(String username, String password) {}
    public record TokenResponse(String token) {}

    @PostMapping("/register")
    public ResponseEntity<String> register(@RequestBody AuthRequest req) {
        authService.register(req.username(), req.password());
        return ResponseEntity.status(201).body("가입 완료");
    }

    @PostMapping("/login")
    public ResponseEntity<TokenResponse> login(@RequestBody AuthRequest req) {
        String token = authService.login(req.username(), req.password());
        return ResponseEntity.ok(new TokenResponse(token));
    }
}
