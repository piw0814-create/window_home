package login_server;


import jakarta.persistence.*;
import lombok.*;

@Entity
@Table(name="posts100")
@Getter @Builder @NoArgsConstructor @AllArgsConstructor
public class Post {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    
    @Column(nullable = false)
    private String title;
    
    @Column(columnDefinition = "TEXT")
    private String content;
}