package login_server;

import jakarta.persistence.*;
import lombok.*;
import org.hibernate.annotations.CreationTimestamp;
import java.time.LocalDateTime;

// DTO로써 데이터 베이스와 연동되는 클래스임을 정의한다.
// Entity 하나는 테이블 하나를 의미한다.
// 이 클래스에 정의되어 있는 변수들과 동일한 이름, 동일한 타입으로 테이블 내의 컬럼들이
// 만들어진다. 그리고 각 변수에 설정한 어노테이션을 보고 각 컬럼의 성격도 결정한다.
@Entity
// 데이블 이름
@Table(name = "users100")
@Getter
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class User {

    // PrimaryKey
    @Id
    // 시퀀스
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    // nullable : false를 주면 null값을 허용하지 않는다.
    // unique : true를 주면 unqiue가 설정된다.
    // length : 글자 길이
    @Column(nullable = false, unique = true, length = 50)
    private String username;

    @Column(nullable = false, length = 255)
    private String password;

    // 날짜 데이터를 담는 컬럼임을 명시
    @CreationTimestamp
    // name : 컬럼 이름을 새롭게 정의하고 싶을 때. 생략하면 변수 이름이 컬럼 명이 된다.
    // updatable : false를 넣어주면 데이터의 수정이 불가능하다.
    @Column(name = "created_at", nullable = false, updatable = false)
    private LocalDateTime createdAt;
}