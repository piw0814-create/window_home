package login_server;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

// Repository : 데이터 베이스와 연동되는 작업이 구현된어 있는 클래스
// JPA를 적용한 Repository의 경우 내부에 정의한 메서드의 이름이 매우 중요하다.
@Repository
// JpaRepository<User, Long> : 여기에 사용할 엔티티 클래스 이름을 지정해야 한다.
// 이것을 통해서 어떠한 테이블을 사용할지가 결정된다.
public interface UserRepository extends JpaRepository<User, Long> {
    // 메서드는 코드 내용없이 추상 메서드 형태로 정의를 해준다.
    // 이 때, 메서드의 이름을 보고 어떠한 작업을 할 메서드인지 파악해서
    // 그에 맞는 코드가 자동완성된다.
    // JPA는 Repository에 정확한 규칙에 따라 메서드의 이름을 작성해주는 것이 핵심이다...
    // https://priming.tistory.com/114
    Optional<User> findByUsername(String username);
    boolean existsByUsername(String username);
}
