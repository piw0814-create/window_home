package login_server;


import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/posts")
@RequiredArgsConstructor
public class PostController {
    private final PostService postService;

    @PostMapping
    public ResponseEntity<PostService.PostResponse> create(@RequestBody PostService.PostRequest req) {
        return ResponseEntity.status(201).body(postService.create(req));
    }
}