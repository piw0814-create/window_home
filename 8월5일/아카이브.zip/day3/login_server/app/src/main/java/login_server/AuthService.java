package login_server;


import java.util.HashMap;
import java.util.Map;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

// 사용자 인증 처리를 하는 클래스
// @Service : 객체를 자동으로 생성하는 기능만 생긴다.
// 개발자가 비즈니스 로직을 구현한 클래스라는 의미로 사용한다.
@Service
public class AuthService {
    private final TokenProvider tokenProvider;
    private final Map<String, User> store = new HashMap<>();

    // @Autowired : IoC 컨테이너에 있는 객체 중에 TokenProvider 타입의
    // 객체를 추출하여 변수에 자동으로 담아준다(DI)
    // 만약 객체가 없으면 새롭게 생성하여 IoC 컨테이너에 담아주고 그 객체를
    // 변수에 담아준다.
    @Autowired
    public AuthService(TokenProvider tokenProvider) {
        this.tokenProvider = tokenProvider;
    }

    // 사용자 등록을 하는 메서드
    public void register(String id, String pw) {
        if (store.containsKey(id)) throw new RuntimeException("이미 존재하는 ID");
        store.put(id, User.of(id, pw));
    }

    // 로그인 처리를 하는 메서드
    public String login(String id, String pw) {
        User user = store.get(id);
        if (user == null || !user.matchPw(pw)) {
            throw new RuntimeException("인증 실패");
        }
        return tokenProvider.generate(id);
    }
}