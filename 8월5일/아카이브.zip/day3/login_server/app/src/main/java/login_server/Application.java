package login_server;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * @SpringBootApplication: Spring Boot 구동의 중심이 되는 어노테이션
 * 1) @SpringBootConfiguration: 스프링 환경 설정 등록
 * 2) @EnableAutoConfiguration: 하위 패키지의 의존성 라이브러리 기반 자동 설정(웹서버 등)을 활성화
 * 3) @ComponentScan: 현재 패키지 및 하위 패키지 내의 @Component, @Service, @RestController 등을 탐색하여 Bean으로 등록
 */
@SpringBootApplication
public class Application {
    public static void main(String[] args) {
        // 내장 톰캣(Tomcat) 서버를 구동하고 Spring 애플리케이션 컨테이너를 실행
        SpringApplication.run(Application.class, args);
    }
}
