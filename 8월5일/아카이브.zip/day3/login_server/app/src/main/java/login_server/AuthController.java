package login_server;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

// @Controller : 브라우저가 요청할 때 사용한 주소에 따라 호출될
// 메서드를 설정화여 관리하는 객체 요소
// @RestController : Rest API 서버 작성시 사용하는 어노테이션
@RestController
// 도메인 주소 다음에 나올 sub 주소
// http://도메인주소/api/auth
@RequestMapping("/api/auth")
public class AuthController {
    // AuthService 타입 객체를 주입 받는다.
    @Autowired
    private AuthService authService;

    // HTTP 요청 바디(JSON)를 맵핑받기 위한 DTO (Java Record 구문 활용)
    // 브라우저가 전달하는 데이터를 담기 위한 객체.
    public record AuthRequest(String id, String password) {}
    
    // 클라이언트에게 토큰을 JSON 형태로 응답하기 위한 DTO
    // 브라우저에게 전달할 데이터를 담을 객체
    public record TokenResponse(String token) {}

    /**
     * 회원가입 API 엔드포인트
     * @PostMapping: POST 요청 처리 ("http://localhost:8080/api/auth/register")
     * @RequestBody: 요청 본문(JSON)을 Java 객체(AuthRequest)로 변환
     */
    @PostMapping("/register")
    public ResponseEntity<String> register(@RequestBody AuthRequest req) {
        // 회원가입 비즈니스 로직 실행
        authService.register(req.id(), req.password());
        
        // HTTP Status 201(Created) 상태 코드와 응답 메세지 전달
        return ResponseEntity.status(201).body("가입 완료");
    }

        /**
     * 로그인 API 엔드포인트
     * @PostMapping: POST 요청 처리 ("http://localhost:8080/api/auth/login")
     */
    @PostMapping("/login")
    public ResponseEntity<TokenResponse> login(@RequestBody AuthRequest req) {
        // 인증 수행 후 JWT 토큰 발급받음
        String token = authService.login(req.id(), req.password());
        
        // HTTP Status 200(OK)과 함께 발급받은 JWT 토큰을 JSON 객체로 전달
        return ResponseEntity.ok(new TokenResponse(token));
    }
}
