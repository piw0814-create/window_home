package login_server;

import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.security.Keys;
import java.util.Date;
import java.security.Key;
import org.springframework.stereotype.Component;

// 데이터 암호화 기능을 처리하는 클래스
// @Component : Spring Boot에서 관리할 Bean으로 지정한다.
// 개발자가 직접 객체 생성을 하지 않고 객체 주입이 최초로 발생하면 그 때 객체가 생성된다.
@Component
public class TokenProvider {
    // 데이터 암호화를 위한 암호화 키 값
    private final String SECRET = "day2-secret-key-must-be-at-least-32-chars!!"; 
    private final Key key = Keys.hmacShaKeyFor(SECRET.getBytes());
    
    public String generate(String userId) {
        return Jwts.builder()
                .setSubject(userId)
                .setExpiration(new Date(System.currentTimeMillis() + 1800000)) // 30분
                .signWith(key)
                .compact();
    }
}